package constants;

public interface FileNames { 
String TRAINER_FILENAME = "Trainers.txt"; 
String MEMBER_FILENAME = "Members.txt"; 
String CLASS_FILENAME = "Class.txt"; 
String REGISTRATION_FILENAME = "Registration.txt"; 
} 